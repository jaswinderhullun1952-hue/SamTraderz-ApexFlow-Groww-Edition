import streamlit as st
import pandas as pd
from datetime import datetime
from zoneinfo import ZoneInfo
from apexflow.universe import load_universe
from apexflow.marketdata import fetch_yahoo_snapshot, fetch_groww_ltp
from apexflow.scanner import build_signals
from apexflow.auth import get_groww_token

st.set_page_config(page_title="SamTraderz ApexFlow | Groww Edition", page_icon="📈", layout="wide")
st.markdown("""<style>.block-container{padding-top:1rem;max-width:1600px}[data-testid="stAppViewContainer"]{background:#0b1018;color:#e8edf5}[data-testid="stSidebar"]{background:#111a27}div[data-testid="stMetric"]{background:#121d2b;border:1px solid #24354a;padding:13px;border-radius:10px}.apx-title{font-size:27px;font-weight:800}</style>""",unsafe_allow_html=True)
with st.sidebar:
 st.markdown("## ⚡ ApexFlow")
 st.caption("GROWW EDITION · MANUAL TRADING ONLY")
 mode=st.radio("Market data source",["Free mode · Yahoo Finance","Groww API · subscribed"])
 refresh=st.slider("Refresh interval (seconds)",30,300,60,15)
 scope=st.selectbox("Universe",["All NSE cash EQ stocks","Top 250 by symbol","Top 100 by symbol"])
 capital=st.number_input("Trading capital (₹)",min_value=1000,value=50000,step=5000)
 risk=st.slider("Risk per trade (%)",0.1,2.0,0.5,0.1)
st.markdown('<div class="apx-title">SAMTRADERZ APEXFLOW <span style="color:#36b7a5">MARKET FLOW</span></div>',unsafe_allow_html=True)
st.caption("NSE cash scanner · momentum · relative volume · VWAP estimate · breakout watch · manual decisions")
try:
 universe=load_universe()
except Exception as e:
 st.error(f"Instrument master unavailable: {e}"); st.stop()
if scope!="All NSE cash EQ stocks": universe=universe.head(250 if "250" in scope else 100)
token=get_groww_token()
use_groww=mode.startswith("Groww")
if use_groww and not token:
 st.error("Add GROWW_ACCESS_TOKEN to Streamlit secrets. A paid, active Groww Trading API subscription is required."); st.stop()
st.info(f"Universe: {len(universe):,} NSE cash EQ instruments · Source: {mode}")
@st.cache_data(ttl=refresh,show_spinner=False)
def scan(rows,groww,access_token):
 u=pd.DataFrame(rows)
 return fetch_groww_ltp(u,access_token) if groww else fetch_yahoo_snapshot(u)
try:
 with st.spinner("Scanning stocks..."):
  snap=scan(universe.to_dict("records"),use_groww,token or "")
 signals=build_signals(snap,capital,risk)
except Exception as e:
 st.error(f"Scan failed: {e}"); st.stop()
if snap.empty:
 st.warning("No data returned. Check market hours, internet, provider throttling and symbols."); st.stop()
bull=int((signals.signal=="BULLISH WATCH").sum()) if "signal" in signals else 0
bear=int((signals.signal=="BEARISH WATCH").sum()) if "signal" in signals else 0
a,b,c,d=st.columns(4)
a.metric("Rows returned",f"{len(snap):,}"); b.metric("Bullish watch",bull); c.metric("Bearish watch",bear)
d.metric("High relative volume",int((signals.relative_volume>=1.5).sum()) if "relative_volume" in signals else 0)
if use_groww:
 st.warning("Groww mode currently uses LTP REST snapshots only. It does not yet run the Groww websocket feed; LTP-only rows are not scored as confirmed setups.")
 cols=["symbol","ltp","change_pct","signal","data_status"]
else:
 st.caption("Free Yahoo Finance candles are best-effort and may be delayed, stale, incomplete or throttled. Never assume refresh interval means real-time data.")
 cols=["symbol","ltp","change_pct","relative_volume","vwap","momentum_pct","breakout","signal","score","entry_reference","stop_reference","target_reference","quantity_at_risk","timestamp"]
view=signals[[x for x in cols if x in signals.columns]]
t1,t2,t3,t4=st.tabs(["Market Radar","Bullish Watch","Bearish Watch","Data & Safety"])
with t1: st.dataframe(view,use_container_width=True,hide_index=True,height=600)
with t2: st.dataframe(view[view.signal=="BULLISH WATCH"],use_container_width=True,hide_index=True)
with t3: st.dataframe(view[view.signal=="BEARISH WATCH"],use_container_width=True,hide_index=True)
with t4:
 st.write("Last render:",datetime.now(ZoneInfo("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S IST"))
 st.write("Groww token configured:",bool(token))
 st.markdown("**Safety:** Signals are heuristic filters, not probabilities. Stop/target references are illustrative fixed-percentage levels, not technical levels. Confirm price, liquidity, spread, news and chart structure in Groww before trading. No order endpoints or auto-trading are implemented.")
st.caption("SAMTRADERZ APEXFLOW · Manual trading only · Not investment advice")
st.markdown(f'<meta http-equiv="refresh" content="{refresh}">',unsafe_allow_html=True)
