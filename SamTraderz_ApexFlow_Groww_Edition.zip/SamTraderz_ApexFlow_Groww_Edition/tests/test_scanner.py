import pandas as pd
from apexflow.scanner import build_signals
def test_ltp_only_not_scored():
 x=build_signals(pd.DataFrame([{"symbol":"A","ltp":100,"change_pct":2,"data_status":"LTP ONLY"}]))
 assert x.iloc[0].signal=="NO TRADE"
def test_empty(): assert build_signals(pd.DataFrame()).empty
def test_bullish():
 d=pd.DataFrame([{"symbol":"XYZ","ltp":110,"change_pct":1.2,"relative_volume":2,"vwap":105,"momentum_pct":.5,"breakout":"UP","data_status":"OK"}])
 assert build_signals(d).iloc[0].signal=="BULLISH WATCH"
