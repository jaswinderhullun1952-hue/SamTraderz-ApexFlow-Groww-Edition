# SamTraderz ApexFlow — Groww Edition

Cloud-deployable NSE cash equity scanner. Manual trading only: no order endpoints are called.

## Data reality
**Free mode:** Yahoo Finance 5-minute candles, best-effort. It is unofficial and may be delayed, incomplete, throttled or unavailable. Refreshing the page every 60 seconds does not make the source real-time.
**Groww mode:** Requires an active Groww Trading API subscription and valid access token. This build uses Groww LTP REST snapshots, not a persistent websocket stream. LTP-only rows are deliberately not scored as candle-confirmed setups. Groww documents its streaming feed separately and supports up to 1,000 instruments per subscription.

## Free cloud deployment
1. Upload this project to a GitHub repository.
2. Visit https://share.streamlit.io/ and deploy the repository with `app.py` as main file.
3. Use the assigned Streamlit URL (custom subdomain availability is subject to Streamlit).
4. Select Free mode. The app downloads Groww's public instrument CSV and filters NSE CASH EQ.
5. If the whole universe is throttled, use Top 250 or Top 100.

Free cloud apps may sleep, restart and have compute/network limits. Do not rely on uninterrupted market-open monitoring.

## Optional Groww credentials
1. Activate Groww Trading API in your Groww account.
2. Generate an access token in Groww Trading APIs settings. Groww docs say access tokens expire daily at 6:00 AM.
3. Add `GROWW_ACCESS_TOKEN = "your-token"` in Streamlit Cloud → App settings → Secrets.
4. Restart and choose Groww API mode. Never commit secrets to GitHub or expose them in screenshots/chat.

## Local install and tests
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
pytest -q
streamlit run app.py
```

## Scanner
Heuristic score (not probability): relative volume 25, short momentum 20, VWAP relation 20, recent 60-minute high/low break 20, session change 15. Watch label requires score >=60 and momentum/VWAP alignment. Stop/target values are illustrative fixed-percent references, not support/resistance. Confirm chart, liquidity, spread, news and risk before trading.

## Scope and limits
- Universe: NSE cash EQ only; not F&O contracts. F&O needs a separate dynamic expiry/contract scanner.
- Yahoo batch requests can fail for a large universe.
- Groww integration is REST LTP snapshot only. A production websocket service needs a persistent worker, token renewal, callback lifecycle and shared cache; free cloud hosting is not reliable for always-on streaming.
- No Groww order APIs are used.

Official docs:
- https://groww.in/trade-api
- https://groww.in/trade-api/docs/python-sdk/feed
- https://groww.in/trade-api/docs/curl/instruments
- https://groww.in/trade-api/docs/curl/live-data
- https://groww.in/trade-api/docs/curl
- https://docs.streamlit.io/deploy/streamlit-community-cloud
