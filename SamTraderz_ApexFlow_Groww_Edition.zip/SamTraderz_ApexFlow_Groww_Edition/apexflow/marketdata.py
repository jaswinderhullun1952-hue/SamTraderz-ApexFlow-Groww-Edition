import time,requests
import pandas as pd
import yfinance as yf
def fetch_yahoo_snapshot(universe,batch_size=35):
 syms=universe.symbol.astype(str).tolist(); rows=[]
 for i in range(0,len(syms),batch_size):
  batch=syms[i:i+batch_size]; tickers=[s+".NS" for s in batch]
  try:
   data=yf.download(tickers=tickers,period="5d",interval="5m",group_by="ticker",auto_adjust=False,progress=False,threads=True,timeout=25)
   for sym,ticker in zip(batch,tickers):
    try:
     d=(data[ticker] if isinstance(data.columns,pd.MultiIndex) else data).dropna(how="all").dropna(subset=["Close"])
     if len(d)<2: continue
     last=d.iloc[-1]; close=float(last.Close); prev=float(d.iloc[-2].Close)
     base=d.Volume.iloc[-21:-1]; av=float(base.mean()) if len(base) and base.mean()>0 else 0
     vol=float(last.Volume) if pd.notna(last.Volume) else 0
     tp=(d.High+d.Low+d.Close)/3; vwap=float((tp*d.Volume.fillna(0)).sum()/d.Volume.fillna(0).sum()) if d.Volume.fillna(0).sum()>0 else close
     hi=float(d.High.iloc[-13:-1].max()); lo=float(d.Low.iloc[-13:-1].min())
     mom=(close/float(d.Close.iloc[-4])-1)*100 if len(d)>=4 else 0
     rows.append(dict(symbol=sym,ltp=close,change_pct=(close/prev-1)*100 if prev else 0,volume=vol,avg_volume=av,relative_volume=vol/av if av else 0,vwap=vwap,momentum_pct=mom,breakout="UP" if close>hi else ("DOWN" if close<lo else "—"),data_status="OK",timestamp=str(d.index[-1])))
    except Exception: pass
  except Exception: pass
  if i+batch_size<len(syms): time.sleep(.7)
 return pd.DataFrame(rows)
def fetch_groww_ltp(universe,token,batch_size=50):
 rows=[]; headers={"Authorization":f"Bearer {token}","Accept":"application/json","X-API-VERSION":"1.0"}
 syms=universe.symbol.astype(str).tolist()
 for i in range(0,len(syms),batch_size):
  batch=syms[i:i+batch_size]
  try:
   r=requests.get("https://api.groww.in/v1/live-data/ltp",params={"segment":"CASH","exchange_symbols":",".join("NSE_"+s for s in batch)},headers=headers,timeout=15); r.raise_for_status()
   payload=r.json().get("payload",{})
   for s in batch:
    if payload.get("NSE_"+s) is not None: rows.append(dict(symbol=s,ltp=float(payload["NSE_"+s]),change_pct=0,data_status="LTP ONLY",timestamp=pd.Timestamp.utcnow().isoformat()))
  except Exception: pass
  time.sleep(.22)
 return pd.DataFrame(rows)
