import pandas as pd
def build_signals(snapshot,capital=50000,risk_pct=.5):
 if snapshot is None or snapshot.empty:return pd.DataFrame()
 d=snapshot.copy()
 for c in ["ltp","change_pct","relative_volume","vwap","momentum_pct"]:
  if c not in d:d[c]=0
  d[c]=pd.to_numeric(d[c],errors="coerce").fillna(0)
 if "breakout" not in d:d["breakout"]="—"
 if "data_status" not in d:d["data_status"]="UNKNOWN"
 ok=d.data_status.eq("OK")
 d["score"]=0
 d.loc[ok,"score"]=((d.loc[ok,"relative_volume"]>=1.5).astype(int)*25+(d.loc[ok,"momentum_pct"]>.15).astype(int)*20+(d.loc[ok,"ltp"]>d.loc[ok,"vwap"]).astype(int)*20+(d.loc[ok,"breakout"]=="UP").astype(int)*20+(d.loc[ok,"change_pct"]>0).astype(int)*15)
 d["signal"]="NO TRADE"
 d.loc[ok&(d.score>=60)&(d.ltp>d.vwap)&(d.momentum_pct>0),"signal"]="BULLISH WATCH"
 d.loc[ok&(d.score>=60)&(d.ltp<d.vwap)&(d.momentum_pct<0),"signal"]="BEARISH WATCH"
 d["entry_reference"]=d.ltp
 d["stop_reference"]=d.apply(lambda r:round(r.ltp*.995,2) if r.signal=="BULLISH WATCH" else (round(r.ltp*1.005,2) if r.signal=="BEARISH WATCH" else None),axis=1)
 d["target_reference"]=d.apply(lambda r:round(r.ltp*1.01,2) if r.signal=="BULLISH WATCH" else (round(r.ltp*.99,2) if r.signal=="BEARISH WATCH" else None),axis=1)
 risk_cash=capital*risk_pct/100
 d["quantity_at_risk"]=d.apply(lambda r:int(risk_cash/abs(r.ltp-r.stop_reference)) if pd.notna(r.stop_reference) and abs(r.ltp-r.stop_reference)>0 else 0,axis=1)
 return d.sort_values(["score","relative_volume"],ascending=False).reset_index(drop=True)
