import io
import pandas as pd
import requests
URL="https://growwapi-assets.groww.in/instruments/instrument.csv"
def load_universe():
 r=requests.get(URL,timeout=30); r.raise_for_status()
 d=pd.read_csv(io.BytesIO(r.content),low_memory=False)
 need={"exchange","segment","trading_symbol"}
 if not need.issubset(d.columns): raise ValueError(f"Instrument CSV schema changed; expected {sorted(need)}")
 x=d[(d.exchange.astype(str).str.upper()=="NSE")&(d.segment.astype(str).str.upper()=="CASH")].copy()
 if "series" in x: x=x[x.series.astype(str).str.upper()=="EQ"]
 if "instrument_type" in x: x=x[x.instrument_type.astype(str).str.upper().isin(["EQ","EQUITY","STOCK"])]
 x["symbol"]=x.trading_symbol.astype(str).str.strip()
 x=x[x.symbol.ne("")&x.symbol.ne("NAN")].drop_duplicates("symbol").sort_values("symbol")
 if x.empty: raise ValueError("No NSE cash equity symbols found.")
 return x[["symbol"]].reset_index(drop=True)
