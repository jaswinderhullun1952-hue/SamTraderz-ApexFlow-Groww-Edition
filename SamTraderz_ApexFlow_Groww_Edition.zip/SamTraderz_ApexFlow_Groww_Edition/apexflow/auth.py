import os,streamlit as st
def get_groww_token():
 try:t=st.secrets.get("GROWW_ACCESS_TOKEN","")
 except Exception:t=""
 return str(t or os.getenv("GROWW_ACCESS_TOKEN","")).strip()
